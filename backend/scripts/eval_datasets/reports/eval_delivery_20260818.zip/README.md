# 真实 Agent 端到端评测交付包（2026-08-18）

## 内容清单

| 目录 / 文件 | 说明 |
| --- | --- |
| `methodology.md` | **评测说明**：「事实准确率（Faithfulness）」口径论证、公式、评测流程、可复现性、框架主流性、测试结果与边界局限 |
| `reports/accuracy_report_20260818_95.md` | **汇总报告**（Markdown）：口径定义、本期汇总、分库汇总、每题明细、低分清单、缺口/排除专节、结论 |
| `reports/accuracy_report_20260818_95.json` | 汇总报告（JSON，机器可读，与 MD 同源） |
| `details/per_question_detail_20260818_95.md` | **详细报告**：每题「问题 + 三指标 + Agent 回答全文 + 参考答案全文 + 状态标记」，可逐题人工复核 |
| `scripts/testset_95.jsonl` | 测试集：业务方人工整理的 95 题业务验证集（七大场景） |
| `scripts/run_agent_e2e.py` | 端到端驱动生产真实 Agent 作答，采集系统答案与**实际检索上下文** |
| `scripts/merge_final.py` | 多轮重测结果按优先级合并为每库最终文件 |
| `scripts/score_agent_results.py` | 用评测框架对每题答案评分（judge 模型逐句判定） |
| `scripts/generate_gold_answers.py` | 参考答案（gold）生成（支持跨库检索模式） |
| `scripts/gen_detail_md.py` | 由评分 JSON 重生成每题明细 Markdown |
| `scripts/eval_pkg/` | 评分与报告核心模块快照（agent_accuracy_report / faithfulness_report / ragas_eval / metrics） |

## 本期结果速览

- **事实准确率（Faithfulness）= 75.2%**：系统回答中 75.2% 的陈述句能在知识库原文中找到直接依据（"不乱编、有出处"）。
- **答案贴合度（Answer Relevancy）= 84.7%**：系统"不跑题"能力稳定。
- 分库（事实准确率 / 贴合度）：POC 76.8% / 85.4%、MCX 70.1% / 82.3%、LOC 74.2% / 84.5%。

## 复现（项目容器内）

```bash
# 1) 评分（judge 结果有磁盘缓存，同模型重跑近乎瞬时）
docker exec api-dev python /app/scripts/score_agent_results.py \
  --results kb_3cm2gz6tyb:/app/scripts/eval_datasets/final/kb_3cm2gz6tyb_final.jsonl \
  --results kb_mvng8u1201:/app/scripts/eval_datasets/final/kb_mvng8u1201_final.jsonl \
  --results kb_0368jjmecb:/app/scripts/eval_datasets/final/kb_0368jjmecb_final.jsonl \
  --no-context-metrics --name 20260818_95

# 2) 重生成每题明细
docker exec api-dev python /app/scripts/eval_datasets/gen_detail_md.py
```

重新驱动真实 Agent（改题/补测后）再跑评分：

```bash
# 端到端作答（需生产环境在跑、有登录凭据）
docker exec api-dev python /app/scripts/run_agent_e2e.py --file /app/scripts/eval_datasets/testset_95.jsonl
# 合并多轮结果 -> final/
docker exec api-dev python /app/scripts/eval_datasets/merge_final.py
# 再执行上面的评分与明细步骤
```

## 关键口径提醒

- **「事实准确率」为内部质量口径，不是《AI知识库软件开发合同终稿》验收指标**（合同验收为：答案可接受准确率 ≥80%、引用正确率 ≥95%）。两者口径、判定方法与数据来源不同，不得用本报告替代合同验收结论。
- 忠实度以「本次检索到的上下文」为判定依据；若检索漏掉实际存在的原文，正确内容也可能被判"无据"——该指标同时反映回答质量与检索质量。
